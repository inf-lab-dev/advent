#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_SIZE 26

#define WORD_LENGTH 256

// Node of a trie
typedef struct trie_node
{
    bool is_word;
    struct trie_node *children[ALPHABET_SIZE];
} trie_node;

trie_node *create_node();
void free_node(trie_node *node);
void insert_word(char *word);
bool contains_word(char *word);
bool load_trie(char *file_name);

// Root of the trie
trie_node *trie_root;

// Main function that runs the entire program
int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./advent3 <words-file.txt>\n");

        return 1;
    }

    trie_root = create_node();

    if (!load_trie(argv[1]))
    {
        printf("ERROR: Could not open %s!\n", argv[1]);

        return 1;
    }

    printf("Enter words to check (type 'q' to quit):\n");

    char word[WORD_LENGTH];

    while (true)
    {
        // Ask the user for a word
        printf("Word: ");
        scanf("%s", word);

        if (strcmp(word, "q") == 0)
        {
            break;
        }

        if (contains_word(word))
        {
            printf("'%s' is contained!\n", word);
        }
        else
        {
            printf("'%s' is NOT contained.\n", word);
        }
    }

    free_node(trie_root);

    return 0;
}

// Creates a new trie node
trie_node *create_node()
{
    trie_node *node = malloc(sizeof(trie_node));

    for (int i = 0; i < ALPHABET_SIZE; i++)
    {
        node->children[i] = NULL;
    }

    node->is_word = false;
    return node;
}

// Recursivley frees the memory of a trie node
void free_node(trie_node *node)
{
    if (node == NULL)
    {
        return;
    }

    for (int i = 0; i < ALPHABET_SIZE; i++)
    {
        free_node(node->children[i]);
    }

    free(node);
}

// Inserts the given word into the trie
void insert_word(char *word)
{
    trie_node *cursor = trie_root;
    int length = strlen(word);

    for (int i = 0; i < length; i++)
    {
        int trie_index = tolower(word[i]) - 'a';

        if (cursor->children[trie_index] == NULL)
        {
            cursor->children[trie_index] = create_node();
        }

        cursor = cursor->children[trie_index];
    }

    cursor->is_word = true;
}

// Returns true if the given word is contained within the trie
bool contains_word(char *word)
{
    // TODO: implement me
}

// Loads the trie from the given file_name and retruns true on success
bool load_trie(char *file_name)
{
    FILE *file = fopen(file_name, "r");

    char word[WORD_LENGTH];

    while (fscanf(file, "%s", word) == 1)
    {
        insert_word(word);
    }

    fclose(file);

    return true;
}
