#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define constants for use inside gift loading, you dont need to use any of these
#define GIFTS_AMOUNT 300
#define GIFT_FILE "gift_sizes.txt"

typedef struct
{
    int size;
} gift;

gift gifts[GIFTS_AMOUNT];

void create_gift_list();
void count_packages(void);

int main(void)
{
    create_gift_list();

    count_packages();

    return 0;
}

void count_packages(void)
{
    // TODO: Implement the calculation of packaging sizes
    printf("NOT IMPLEMENTED: You need to implement the `count_packages` function first.\n");
}

// Loads the gifts from the provided file
void create_gift_list()
{
    FILE *file = fopen(GIFT_FILE, "r");

    if (file == NULL)
    {
        printf("ERROR: File '%s' could not be opened.\n", GIFT_FILE);
        exit(1);
    }

    int index = 0;

    while (index < GIFTS_AMOUNT && fscanf(file, "%i", &gifts[index].size) > 0)
    {
        index++;
    }

    if (ferror(file))
    {
        printf("ERROR: Error while reading file '%s'.\n", GIFT_FILE);
        fclose(file);

        exit(1);
    }

    fclose(file);

    if (index < GIFTS_AMOUNT)
    {
        printf("WARNING: Read just %i presents. Expected: %i. Are you sure you have not changed "
               "`%s`?\n",
               index, GIFTS_AMOUNT, GIFT_FILE);
    }
}
