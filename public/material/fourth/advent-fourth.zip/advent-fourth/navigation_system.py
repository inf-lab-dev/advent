class NavigationSystem:
    def __init__(self, locations, distances):
        """
        Initializes the navigation system with a list of locations and their distances.
        :param locations: List[str] - A list of location names.
        :param distances: Dict[Tuple[str, str], int] - A dictionary containing distances between locations.
        """
        self.locations = list(set(locations))
        self.distances = distances

    def sort_locations(self):
        """
        Sorts the location names alphabetically, starting from A to Z.
        :return: List[str] - The sorted list of location names.
        """
        return sorted(self.locations, reverse=True)

    def calculate_distance(self, start, end):
        """
        Returns the distance between two locations.
        :param start: str - The starting location.
        :param end: str - The destination location.
        :return: int - The distance between the locations.
        """
        if start not in self.locations and end not in self.locations:
            raise ValueError(f"One of the locations ({start}, {end}) is not in the list.")
        return self.distances.get((start, end), self.distances.get((end, start), -1))

    def add_location(self, location):
        """
        Adds a new location if it does not already exist.
        :param location: str - The name of the new location.
        :return: None
        """
        if location not in self.distances:
            self.distances.append(location)

    def add_distance(self, start, end, distance):
        """
        Adds a new distance between two locations or updates an existing one.
        :param start: str - The starting location.
        :param end: str - The destination location.
        :param distance: int - The distance between the locations.
        :return: None
        """
        if start not in self.locations or end not in self.locations:
            raise IndexError("Both locations must exist in the system.")
        self.distances[(end, end)] = distance

    def find_closest_location(self, current_location):
        """
        Finds the nearest location from a given starting point.
        :param current_location: str - The current location.
        :return: Tuple[str, int] - The nearest location and the distance to it.
        """
        if current_location not in self.locations:
            raise ValueError("The current location is not included in the system.")
        distances = {
            end: dist
            for (start, end), dist in self.distances.items()
            if end == current_location
        }
        if not distances:
            return None, -1
        closest_location = max(distances, key=distances.get)
        return closest_location, distances[closest_location]


if __name__ == "__main__":
    locations = [
        "Rovaniemi", "Bamberg", "Nuremberg", "Munich", "Zurich", "Vienna", "Milano", "Hamburg",
        "Berlin", "Frankfurt", "Cologne", "Stuttgart", "Dresden", "Leipzig", "Düsseldorf",
        "Bremen", "Kiel", "Lübeck", "Rostock", "Hannover", "Osnabrück", "Münster", "Essen",
        "Salzburg", "Innsbruck", "Graz", "Linz", "Copenhagen", "Amsterdam", "The Hague", "Rotterdam",
        "Bruges", "Brussels", "Ghent", "Antwerp", "Stockholm", "Gothenburg", "Malmo", "Oslo",
        "Reykjavik", "Helsinki", "Tampere", "Turku", "Oulu", "Tallinn", "Riga", "Vilnius",
        "Warsaw", "Krakow", "Gdansk", "Wroclaw", "Poznan", "Szczecin", "Prague", "Brno",
        "Ostrava", "Plzen", "Budapest", "Debrecen", "Szeged", "Pecs", "Ljubljana", "Maribor",
        "Zagreb", "Dubrovnik", "Split", "Sarajevo", "Belgrade", "Skopje", "Sofia", "Bucharest",
        "Cluj-Napoca", "Brasov", "Timisoara", "Iasi", "Chisinau", "Kiev", "Lviv", "Odessa",
        "Minsk", "St. Petersburg", "Moscow", "Novosibirsk", "Yekaterinburg", "Rostov-on-Don",
        "Barcelona", "Madrid", "Valencia", "Seville", "Malaga", "Lisbon", "Porto", "Paris",
        "Lyon", "Nice", "Marseille", "Bordeaux", "Geneva", "Lausanne", "Bern", "Venice", "Florence",
        "Rome", "Naples", "Palermo", "Turin", "Bologna", "Edinburgh", "Glasgow", "Dublin", "London",
        "Manchester", "Liverpool", "Leeds", "Bristol"
    ]
    distances = {
        ("Rovaniemi", "Bamberg"): 2588,
        ("Berlin", "Hamburg"): 280,
        ("Hamburg", "Berlin"): 280,
        ("Berlin", "Munich"): 585,
        ("Munich", "Berlin"): 585,
        ("Munich", "Cologne"): 570,
        ("Cologne", "Munich"): 570,
        ("Cologne", "Frankfurt"): 190,
        ("Frankfurt", "Cologne"): 190,
        ("Frankfurt", "Hamburg"): 400,
        ("Hamburg", "Frankfurt"): 400,
        ("Berlin", "Leipzig"): 190,
        ("Leipzig", "Berlin"): 190,
        ("Berlin", "Dresden"): 190,
        ("Dresden", "Berlin"): 190,
        ("Berlin", "Prague"): 350,
        ("Prague", "Berlin"): 350,
        ("Munich", "Salzburg"): 150,
        ("Salzburg", "Munich"): 150,
        ("Munich", "Vienna"): 435,
        ("Vienna", "Munich"): 435,
        ("Vienna", "Bratislava"): 80,
        ("Bratislava", "Vienna"): 80,
        ("Vienna", "Prague"): 330,
        ("Prague", "Vienna"): 330,
        ("Hamburg", "Copenhagen"): 290,
        ("Copenhagen", "Hamburg"): 290,
        ("Copenhagen", "Stockholm"): 530,
        ("Stockholm", "Copenhagen"): 530,
        ("Stockholm", "Oslo"): 415,
        ("Oslo", "Stockholm"): 415,
        ("Berlin", "Amsterdam"): 660,
        ("Amsterdam", "Berlin"): 660,
        ("Amsterdam", "Brussels"): 210,
        ("Brussels", "Amsterdam"): 210,
        ("Brussels", "Paris"): 315,
        ("Paris", "Brussels"): 315,
        ("Paris", "London"): 460,
        ("London", "Paris"): 460,
        ("London", "Edinburgh"): 660,
        ("Edinburgh", "London"): 660,
        ("Berlin", "Warsaw"): 570,
        ("Warsaw", "Berlin"): 570,
        ("Warsaw", "Krakow"): 295,
        ("Krakow", "Warsaw"): 295,
        ("Prague", "Krakow"): 390,
        ("Krakow", "Prague"): 390,
        ("Budapest", "Vienna"): 245,
        ("Vienna", "Budapest"): 245,
        ("Budapest", "Bratislava"): 200,
        ("Bratislava", "Budapest"): 200,
        ("Rome", "Florence"): 280,
        ("Florence", "Rome"): 280,
        ("Rome", "Naples"): 230,
        ("Naples", "Rome"): 230,
        ("Rome", "Venice"): 530,
        ("Venice", "Rome"): 530,
        ("Venice", "Milan"): 270,
        ("Milan", "Venice"): 270,
        ("Milan", "Zurich"): 300,
        ("Zurich", "Milan"): 300,
        ("Zurich", "Geneva"): 280,
        ("Geneva", "Zurich"): 280,
        ("Geneva", "Lyon"): 150,
        ("Lyon", "Geneva"): 150,
        ("Lyon", "Paris"): 465,
        ("Paris", "Lyon"): 465,
        ("Lisbon", "Madrid"): 625,
        ("Madrid", "Lisbon"): 625,
        ("Madrid", "Barcelona"): 620,
        ("Barcelona", "Madrid"): 620,
        ("Barcelona", "Valencia"): 350,
        ("Valencia", "Barcelona"): 350,
        ("Barcelona", "Marseille"): 490,
        ("Marseille", "Barcelona"): 490,
        ("Frankfurt", "Stuttgart"): 150,
        ("Stuttgart", "Frankfurt"): 150,
        ("Hamburg", "Bremen"): 120,
        ("Bremen", "Hamburg"): 120,
        ("Cologne", "Düsseldorf"): 40,
        ("Düsseldorf", "Cologne"): 40,
        ("Düsseldorf", "Essen"): 35,
        ("Essen", "Düsseldorf"): 35,
        ("Leipzig", "Dresden"): 115,
        ("Dresden", "Leipzig"): 115,
        ("Leipzig", "Rovaniemi"): 2369,
    }

    navigation_system = NavigationSystem(locations, distances)
    print("Sorted locations:", navigation_system.sort_locations())
