import pytest
from navigation_system import NavigationSystem


def test_sort_locations():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    sorted_locations = navigation_system.sort_locations()
    assert sorted_locations == ["Berlin", "Hamburg", "Köln", "München"]


def test_calculate_distance_valid():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    assert navigation_system.calculate_distance("Berlin", "Hamburg") == 280
    assert navigation_system.calculate_distance("Hamburg", "Berlin") == 280


def test_calculate_distance_invalid():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    with pytest.raises(ValueError):
        navigation_system.calculate_distance("Berlin", "Leipzig")


def test_add_location():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    navigation_system.add_location("Leipzig")
    assert "Leipzig" in navigation_system.locations
    navigation_system.add_location("Berlin")
    assert navigation_system.locations.count("Berlin") == 1


def test_add_distance():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)

    navigation_system.add_location("Leipzig")
    navigation_system.add_distance("Berlin", "Leipzig", 150)
    assert navigation_system.calculate_distance("Berlin", "Leipzig") == 150

    with pytest.raises(ValueError):
        navigation_system.add_distance("Berlin", "Paris", 1050)


def test_find_closest_location():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    closest_location, distance = navigation_system.find_closest_location("Berlin")
    assert closest_location == "Hamburg"
    assert distance == 280


def test_find_closest_location_no_connections():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    navigation_system.add_location("Leipzig")
    closest_location, distance = navigation_system.find_closest_location("Leipzig")
    assert closest_location is None
    assert distance == -1


def test_find_closest_location_invalid_location():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    navigation_system = NavigationSystem(locations, distances)
    with pytest.raises(ValueError):
        navigation_system.find_closest_location("Paris")


def test_find_long_distances():
    locations = ["Berlin", "Hamburg", "München", "Köln"]
    distances = {
        ("Berlin", "Hamburg"): 280,
        ("Berlin", "München"): 584,
        ("Hamburg", "Köln"): 360,
        ("Köln", "München"): 480,
    }
    expected_long_distances = [
        ("Berlin", "München", 584),
        ("Köln", "München", 480)
    ]
    navigation_system = NavigationSystem(locations, distances)
    # Check if the method exists
    assert hasattr(navigation_system, 'find_long_distances'), "Method 'find_long_distances' does not exist. Did you implement it?"

    long_distances = navigation_system.find_long_distances(400)
    assert sorted(long_distances) == sorted(expected_long_distances)


def test_find_long_distances_empty():
    locations = ["Berlin", "Hamburg"]
    distances = {
        ("Berlin", "Hamburg"): 100,
        ("Hamburg", "Berlin"): 100,
    }
    navigation_system = NavigationSystem(locations, distances)
    # Check if the method exists
    assert hasattr(navigation_system, 'find_long_distances'), "Method 'find_long_distances' does not exist. Did you implement it?"

    long_distances = navigation_system.find_long_distances(150)
    expected = []
    assert long_distances == expected
